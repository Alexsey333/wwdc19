/*:
 # 🏁 Welcome to RaceTrack 🏎
 ## Time to show your reaction speed and driving skills
 ## Your task as soon as possible to go through all the checkpoints and cross the finish line
 ## Ready? Then let's go!
 
 # Control 🕹
 ## Car control buttons:
 - Forward: **W** or ⬆️
 - Back: **S** or ⬇️
 - Wheels to the right: **D** or ➡️
 - Wheels to the left: **A** or ⬅️
 
 ## Camera control buttons:
 - Standard third-person camera: 1️⃣
 - Distant third-person camera: 2️⃣
 - First person camera: 3️⃣
 
 ## Command buttons:
 - Pause: **P**
 
 This button pauses the game and gives you the opportunity to freely explore the scene using the mouse or touchpad. Press again to continue the game.
 
 - Сheckpoint: **C**
 
 The checkpoint button returns you to the last passed checkpoint, this is useful if you left the track or the car turned over
 
 - Restart: **R**
 
 The restart button takes you back to the starting line, use it to start a new race.
 
 - Help: **H**
 
 If you have problems passing the track, you can move to the next checkpoint by pressing this button, but this will result in a penalty of 30 seconds.
 */
import PlaygroundSupport


import SceneKit

let game = GameViewController()
/*:
 # View Size setting
 Below is a list of sizes, if you want to change the size of the view, select the appropriate option from the list.
 */
let viewSize: [Int: CGRect] = [
    1: CGRect(x: 0, y: 0, width: 600, height: 450),
    2: CGRect(x: 0, y: 0, width: 800, height: 600),
    3: CGRect(x: 0, y: 0, width: 1024, height: 768),
    4: CGRect(x: 0, y: 0, width: 1200, height: 900)
]
game.view = SCNView(frame: viewSize[3]!) // <-- Enter your size number here

game.viewDidLoad()
PlaygroundPage.current.liveView = game
