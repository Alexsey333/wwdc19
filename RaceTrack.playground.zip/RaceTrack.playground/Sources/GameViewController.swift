import SceneKit

struct PhysicsMask : OptionSet {
    let rawValue: Int
    
    static let vehicle = PhysicsMask(rawValue: 1 << 0)
    static let startLine = PhysicsMask(rawValue: 1 << 1)
    static let checkpoint1 = PhysicsMask(rawValue: 1 << 2)
    static let checkpoint2 = PhysicsMask(rawValue: 1 << 3)
    static let checkpoint3 = PhysicsMask(rawValue: 1 << 4)
    static let loop1start = PhysicsMask(rawValue: 1 << 5)
    static let loop1end = PhysicsMask(rawValue: 1 << 6)
    static let loop2start = PhysicsMask(rawValue: 1 << 7)
    static let loop2end = PhysicsMask(rawValue: 1 << 8)
}

public class GameViewController: NSViewController, SCNPhysicsContactDelegate {
    
    private var scnView: SCNView!
    private var scene: SCNScene!
    
    private var vehicleNode: SCNNode!
    private var vehicle = SCNPhysicsVehicle()
    private var vehicleSteering = CGFloat(0.0)
    private var engineForce = CGFloat(0.0)
    
    private var startLine: SCNNode!
    private var checkpoint1: SCNNode!
    private var checkpoint2: SCNNode!
    private var checkpoint3: SCNNode!
    private var checkpoint = "startLine"
    private var mode = "title"
    private var gameOn = false
    private var seconds = 0
    private var record = 999
    
    private var camera1: SCNNode!
    private var camera2: SCNNode!
    private var camera3: SCNNode!
    private var lastPlayerCamera = "camera1"
    private var loopСamera = ""
    
    private var timeNode: SCNNode!
    private var timeText: SCNText!
    private var startNode: SCNNode!
    private var startText: SCNText!
    private var recordText: SCNText!
    private var titleNode: SCNNode!
    private var messageNode: SCNNode!
    private var messageText: SCNText!
    
    private var loop1camera: SCNNode!
    private var loop1start: SCNNode!
    private var loop1end: SCNNode!
    
    private var loop2camera: SCNNode!
    private var loop2start: SCNNode!
    private var loop2end: SCNNode!
    
    private var gameSound: SCNAction!
    private var relaxSound: SCNAction!
    private var checkpointSound: SCNAction!
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        // receive view
        scnView = self.view as? SCNView
        
        // setup the scene
        scene = setupScene()
        
        // present it
        scnView.scene = scene
        
        // set physicsContactDelegate
        scnView.scene!.physicsWorld.contactDelegate = self
        
        // setup the sound
        setupSound()
        
        // initial point of view
        scnView.pointOfView = camera1
        
        // initial music theme
        vehicleNode.runAction(relaxSound, forKey: "relax")
        
        // debug
        // show physicsShapes
        // scnView.debugOptions = [.showPhysicsShapes]
        // show statistics such as fps and timing information
        // scnView.showsStatistics = true
    }
    
    private func setupSceneElements(_ scene: SCNScene) {
        
        let racetrack = scene.rootNode.childNode(withName: "racetrack", recursively: false)!
        let racetrackPhysicsShape = SCNPhysicsShape(node: racetrack, options: [SCNPhysicsShape.Option.type: SCNPhysicsShape.ShapeType.concavePolyhedron])
        racetrack.physicsBody = SCNPhysicsBody(type: .static, shape: racetrackPhysicsShape)
        
        titleNode = scene.rootNode.childNode(withName: "title", recursively: false)!
        
        startLine = scene.rootNode.childNode(withName: "startLine", recursively: false)!
        startLine.physicsBody!.categoryBitMask = PhysicsMask.startLine.rawValue
        startLine.physicsBody!.collisionBitMask = PhysicsMask.startLine.rawValue
        startLine.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        
        checkpoint1 = scene.rootNode.childNode(withName: "checkpoint1", recursively: false)!
        checkpoint1.physicsBody!.categoryBitMask = PhysicsMask.checkpoint1.rawValue
        checkpoint1.physicsBody!.collisionBitMask = PhysicsMask.checkpoint1.rawValue
        checkpoint1.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        checkpoint1.isHidden = true
        
        checkpoint2 = scene.rootNode.childNode(withName: "checkpoint2", recursively: false)!
        checkpoint2.physicsBody!.categoryBitMask = PhysicsMask.checkpoint2.rawValue
        checkpoint2.physicsBody!.collisionBitMask = PhysicsMask.checkpoint2.rawValue
        checkpoint2.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        checkpoint2.isHidden = true
        
        checkpoint3 = scene.rootNode.childNode(withName: "checkpoint3", recursively: false)!
        checkpoint3.physicsBody!.categoryBitMask = PhysicsMask.checkpoint3.rawValue
        checkpoint3.physicsBody!.collisionBitMask = PhysicsMask.checkpoint3.rawValue
        checkpoint3.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        checkpoint3.isHidden = true
        
        timeNode = SCNNode()
        timeNode.position = SCNVector3Make(1.2, 0, -10)
        timeNode.scale = SCNVector3Make(0.03, 0.03, 0.03)
        timeNode.eulerAngles = SCNVector3Make(0, CGFloat.pi, 0)
        timeNode.geometry = SCNText()
        timeNode.isHidden = true
        
        timeText = timeNode.geometry as? SCNText
        timeText.font = NSFont(name: "Helvetica Bold Oblique", size: 64)
        timeText.string = "00"
        
        startNode = scene.rootNode.childNode(withName: "start_text", recursively: true)!
        startText = startNode.geometry as? SCNText
        
        recordText = scene.rootNode.childNode(withName: "record_time", recursively: true)!.geometry as? SCNText
        
        messageNode = SCNNode()
        messageNode.position = SCNVector3Make(5.5, 8, -10)
        messageNode.scale = SCNVector3Make(0.03, 0.03, 0.03)
        messageNode.eulerAngles = SCNVector3Make(0, CGFloat(Double.pi), 0)
        messageNode.geometry = SCNText()
        messageNode.isHidden = true
        
        messageText = messageNode.geometry as? SCNText
        messageText.font = NSFont(name: "Helvetica Bold Oblique", size: 64)
        messageText.string = "New record!"
        messageText.firstMaterial!.diffuse.contents = NSColor.yellow
        
        let look = SCNLookAtConstraint(target: timeNode)
        
        loop1camera = scene.rootNode.childNode(withName: "loop1camera", recursively: true)!
        loop1camera.constraints?.append(look)
        
        loop1start = scene.rootNode.childNode(withName: "loop1start", recursively: true)!
        loop1start.physicsBody!.categoryBitMask = PhysicsMask.loop1start.rawValue
        loop1start.physicsBody!.collisionBitMask = PhysicsMask.loop1start.rawValue
        loop1start.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        
        loop1end = scene.rootNode.childNode(withName: "loop1end", recursively: true)!
        loop1end.physicsBody!.categoryBitMask = PhysicsMask.loop1end.rawValue
        loop1end.physicsBody!.collisionBitMask = PhysicsMask.loop1end.rawValue
        loop1end.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        
        loop2camera = scene.rootNode.childNode(withName: "loop2camera", recursively: true)!
        loop2camera.constraints?.append(look)
        
        loop2start = scene.rootNode.childNode(withName: "loop2start", recursively: true)!
        loop2start.physicsBody!.categoryBitMask = PhysicsMask.loop2start.rawValue
        loop2start.physicsBody!.collisionBitMask = PhysicsMask.loop2start.rawValue
        loop2start.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
        
        loop2end = scene.rootNode.childNode(withName: "loop2end", recursively: true)!
        loop2end.physicsBody!.categoryBitMask = PhysicsMask.loop2end.rawValue
        loop2end.physicsBody!.collisionBitMask = PhysicsMask.loop2end.rawValue
        loop2end.physicsBody!.contactTestBitMask = PhysicsMask.vehicle.rawValue
    }
    
    private func setupVehicle(_ scene: SCNScene) -> SCNNode {
        
        let chassisNode = scene.rootNode.childNode(withName: "rccarBody", recursively: true)!
        
        let body = SCNPhysicsBody.dynamic()
        body.allowsResting = false
        body.mass = 60
        body.categoryBitMask = PhysicsMask.vehicle.rawValue
        
        chassisNode.physicsBody = body
        
        //add wheels
        let wheelnode0 = chassisNode.childNode(withName: "wheelLocator_FL", recursively: true)!
        let wheelnode1 = chassisNode.childNode(withName: "wheelLocator_FR", recursively: true)!
        let wheelnode2 = chassisNode.childNode(withName: "wheelLocator_RL", recursively: true)!
        let wheelnode3 = chassisNode.childNode(withName: "wheelLocator_RR", recursively: true)!
        
        let wheel0 = SCNPhysicsVehicleWheel(node: wheelnode0)
        let wheel1 = SCNPhysicsVehicleWheel(node: wheelnode1)
        let wheel2 = SCNPhysicsVehicleWheel(node: wheelnode2)
        let wheel3 = SCNPhysicsVehicleWheel(node: wheelnode3)
        
        wheel0.connectionPosition = SCNVector3Make( -2, 2.06, 2.7)
        wheel1.connectionPosition = SCNVector3Make( 2, 2.06, 2.7)
        wheel2.connectionPosition = SCNVector3Make( -2, 2.06, -3.56)
        wheel3.connectionPosition = SCNVector3Make( 2, 2.06, -3.56)
        
        // create the physics vehicle
        let vehicle = SCNPhysicsVehicle(chassisBody: chassisNode.physicsBody!, wheels: [wheel0, wheel1, wheel2, wheel3])
        scene.physicsWorld.addBehavior(vehicle)
        
        self.vehicle = vehicle
        
        return chassisNode
    }
    
    private func setupSound() {
        gameSound = SCNAction.repeatForever(SCNAction.playAudio(SCNAudioSource(fileNamed: "game_theme.mp3")!, waitForCompletion: true))
        relaxSound = SCNAction.repeatForever(SCNAction.playAudio(SCNAudioSource(fileNamed: "relax_theme.mp3")!, waitForCompletion: true))
        checkpointSound = SCNAction.playAudio(SCNAudioSource(fileNamed: "checkpoint.mp3")!, waitForCompletion: true)
    }
    
    private func setupScene() -> SCNScene {
        // receive scene
        let scene = SCNScene(named: "scene.scn")!
        
        // setup elements
        setupSceneElements(scene)
        
        // setup vehicle
        vehicleNode = setupVehicle(scene)
        
        // receive camera1
        camera1 = scene.rootNode.childNode(withName: "camera1", recursively: false)!
        
        // add additional cameras to the vehicle
        camera2 = SCNNode()
        camera2.camera = SCNCamera()
        camera2.camera!.zFar = 2000
        camera2.camera!.zNear = 1
        camera2.position = SCNVector3(0, 10, -40)
        camera2.eulerAngles = SCNVector3Make(0, CGFloat(Double.pi), 0)
        vehicleNode.addChildNode(camera2)
        
        camera3 = SCNNode()
        camera3.camera = SCNCamera()
        camera3.camera!.zFar = 2000
        camera3.camera!.zNear = 1
        camera3.position = SCNVector3(0, 4, 0)
        camera3.eulerAngles = SCNVector3Make(0, CGFloat(Double.pi), 0)
        vehicleNode.addChildNode(camera3)
        
        // add time display
        vehicleNode.addChildNode(timeNode)
        
        // add message display
        vehicleNode.addChildNode(messageNode)
        
        return scene
    }
    
    private func getCamera(name: String) -> SCNNode {
        switch name {
        case "camera1":
            return camera1
        case "camera2":
            return camera2
        case "camera3":
            return camera3
        case "loop1camera":
            return loop1camera
        case "loop2camera":
            return loop1camera
        default:
            return camera1
        }
    }
    
    private func title() {
        mode = "wait"
        let pressAnyKey = scene.rootNode.childNode(withName: "pressAnyKey", recursively: true)!
        pressAnyKey.isHidden = true
        camera1.runAction(SCNAction.group([SCNAction.move(to: SCNVector3Make(0, 15, 40), duration: 3), SCNAction.rotateTo(x: 0.0, y: 0.0, z: 0.0, duration: 3, usesShortestUnitArc: true)])){
            self.titleNode.isHidden = true
            self.vehicleNode.addChildNode(self.camera1)
            self.camera1.eulerAngles = SCNVector3Make(0, CGFloat(Double.pi), 0)
            self.camera1.position = SCNVector3(0, 10, -40)
            self.mode = "game"
        }
    }
    
    public override func keyDown(with event: NSEvent) {
        if mode == "title" {
            title()
        } else if mode == "game" {
            if event.keyCode == 18 { // camera 1
                scnView.pointOfView = camera1
                lastPlayerCamera = "camera1"
                loopСamera = ""
            }
            if event.keyCode == 19 { // camera 2
                scnView.pointOfView = camera2
                lastPlayerCamera = "camera2"
                loopСamera = ""
            }
            if event.keyCode == 20 { // camera 3
                scnView.pointOfView = camera3
                lastPlayerCamera = "camera3"
                loopСamera = ""
            }
            if event.keyCode == 15 { // restart
                scnView.pointOfView = getCamera(name: lastPlayerCamera)
                loopСamera = ""
                vehicleNode.physicsBody!.clearAllForces()
                vehicleNode.position = SCNVector3Make(0, 3, 0)
                vehicleNode.eulerAngles = SCNVector3Make(0, 0, 0)
                vehicleNode.removeAllActions()
                vehicleNode.removeAllAudioPlayers()
                vehicleNode.runAction(relaxSound)
                timeNode.position.x = 1.2
                seconds = 0
                gameOn = false
                
                timeText.string = "00"
                startText.string = "START"
                if record == 999 {
                    recordText.string = "0:00"
                }
                
                startNode.position.x = -4.5
                startLine.isHidden = false
                timeNode.isHidden = true
                messageNode.isHidden = true
                checkpoint1.isHidden = true
                checkpoint2.isHidden = true
                checkpoint3.isHidden = true
                checkpoint = "startLine"
            }
            if event.keyCode == 8 { // checkpoint
                scnView.pointOfView = getCamera(name: lastPlayerCamera)
                loopСamera = ""
                if checkpoint == "startLine" {
                    vehicleNode.physicsBody!.clearAllForces()
                    vehicleNode.position = SCNVector3Make(0, 3, 0)
                    vehicleNode.eulerAngles = SCNVector3Make(0, 0, 0)
                }
                if checkpoint == "checkpoint1" {
                    vehicleNode.physicsBody!.clearAllForces()
                    vehicleNode.position = SCNVector3Make(-150, 3, 1700)
                    vehicleNode.eulerAngles = SCNVector3Make(0, -CGFloat.pi / 2, 0)
                }
                if checkpoint == "checkpoint2" {
                    vehicleNode.physicsBody!.clearAllForces()
                    vehicleNode.position = SCNVector3Make(400, 3, 650)
                    vehicleNode.eulerAngles = SCNVector3Make(0, -CGFloat.pi / 2, 0)
                }
                if checkpoint == "checkpoint3" {
                    vehicleNode.physicsBody!.clearAllForces()
                    vehicleNode.position = SCNVector3Make(-250, 0, 0)
                    vehicleNode.eulerAngles = SCNVector3Make(0, CGFloat.pi, 0)
                }
            }
            if event.keyCode == 35 { // pause
                if scene.isPaused == false {
                    scene.isPaused = true
                    scnView.allowsCameraControl = true
                } else {
                    scnView.allowsCameraControl = false
                    if loopСamera == "" {
                        scnView.pointOfView = getCamera(name: lastPlayerCamera)
                    } else {
                        scnView.pointOfView = getCamera(name: loopСamera)
                    }
                    scene.isPaused = false
                }
            }
            if event.keyCode == 4 { // help
                if gameOn {
                    scnView.pointOfView = getCamera(name: lastPlayerCamera)
                    loopСamera = ""
                    if checkpoint == "startLine" {
                        vehicleNode.physicsBody!.clearAllForces()
                        vehicleNode.position = SCNVector3Make(-150, 3, 1700)
                        vehicleNode.eulerAngles = SCNVector3Make(0, -CGFloat.pi / 2, 0)
                    }
                    if checkpoint == "checkpoint1" {
                        vehicleNode.physicsBody!.clearAllForces()
                        vehicleNode.position = SCNVector3Make(400, 3, 650)
                        vehicleNode.eulerAngles = SCNVector3Make(0, -CGFloat.pi / 2, 0)
                    }
                    if checkpoint == "checkpoint2" {
                        vehicleNode.physicsBody!.clearAllForces()
                        vehicleNode.position = SCNVector3Make(-250, 0, 0)
                        vehicleNode.eulerAngles = SCNVector3Make(0, CGFloat.pi, 0)
                    }
                    if checkpoint == "checkpoint3" {
                        vehicleNode.physicsBody!.clearAllForces()
                        vehicleNode.position = SCNVector3Make(0, 3, 0)
                        vehicleNode.eulerAngles = SCNVector3Make(0, 0, 0)
                    }
                    seconds = seconds + 30
                }
            }
            if event.keyCode == 49 { // stop vehicle
                engineForce = CGFloat(0.0)
                
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 0)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 1)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 2)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 3)
            }
            if event.keyCode == 126 || event.keyCode == 13 { // forward
                engineForce = CGFloat(600.0)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 0)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 1)
            }
            if event.keyCode == 125 || event.keyCode == 1 { // back
                engineForce = CGFloat(-100.0)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 2)
                self.vehicle.applyEngineForce(engineForce, forWheelAt: 3)
            }
            if event.keyCode == 123 || event.keyCode == 0 { // left
                if vehicleSteering < 0.6 {
                    vehicleSteering += 0.1
                }
                self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 0)
                self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 1)
            }
            if event.keyCode == 124 || event.keyCode == 2 { // right
                if vehicleSteering > -0.6 {
                    vehicleSteering -= 0.1
                }
                self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 0)
                self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 1)
            }
        }
    }
    
    public override func keyUp(with event: NSEvent) {
        if event.keyCode == 126 || event.keyCode == 13 { // forward
            engineForce = CGFloat(0.0)
            self.vehicle.applyEngineForce(engineForce, forWheelAt: 0)
            self.vehicle.applyEngineForce(engineForce, forWheelAt: 1)
        }
        if event.keyCode == 125 || event.keyCode == 1 { // back
            engineForce = CGFloat(0.0)
            self.vehicle.applyEngineForce(engineForce, forWheelAt: 2)
            self.vehicle.applyEngineForce(engineForce, forWheelAt: 3)
        }
        if event.keyCode == 123 || event.keyCode == 0 { // left
            vehicleSteering = 0
            self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 0)
            self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 1)
        }
        if event.keyCode == 124 || event.keyCode == 2 { // right
            vehicleSteering = 0
            self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 0)
            self.vehicle.setSteeringAngle(vehicleSteering, forWheelAt: 1)
        }
    }
    
    public func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
        let contactMask = contact.nodeA.physicsBody!.categoryBitMask | contact.nodeB.physicsBody!.categoryBitMask
        
        switch contactMask {
        case PhysicsMask.vehicle.rawValue | PhysicsMask.startLine.rawValue:
            if checkpoint == "startLine" && gameOn == false { // start
                vehicleNode.removeAction(forKey: "relax")
                vehicleNode.removeAllAudioPlayers()
                vehicleNode.runAction(checkpointSound)
                vehicleNode.runAction(gameSound, forKey: "game")
                gameOn = true
                
                let Timer = SCNAction.wait(duration: 1.0)
                let runBlock = SCNAction.run { (node) in
                    self.seconds = self.seconds + 1
                    
                    let minute = (self.seconds % 3600) / 60
                    let second = (self.seconds % 3600) % 60
                    if minute == 0 {
                        self.timeNode.position.x = 1.2
                        if second < 10 {
                            self.timeText.string = String("0\(second)")
                            if self.record == 999 {
                                self.recordText.string = String("0:0\(second)")
                            }
                        } else {
                            self.timeText.string = String(second)
                            if self.record == 999 {
                                self.recordText.string = String("0:\(second)")
                            }
                        }
                    } else {
                        self.timeNode.position.x = 2.2
                        if second < 10 {
                            self.timeText.string = String("\(minute):0\(second)")
                            if self.record == 999 {
                                self.recordText.string = String("\(minute):0\(second)")
                            }
                        } else {
                            self.timeText.string = String("\(minute):\(second)")
                            if self.record == 999 {
                                self.recordText.string = String("\(minute):\(second)")
                            }
                        }
                    }
                }
                
                vehicleNode.runAction(SCNAction.repeatForever(SCNAction.sequence([Timer, runBlock])), forKey: "timer")
                timeNode.isHidden = false
                startLine.isHidden = true
                checkpoint1.isHidden = false
            }
            if checkpoint == "checkpoint3" && gameOn { // finish
                vehicleNode.removeAction(forKey: "game")
                vehicleNode.removeAllAudioPlayers()
                vehicleNode.removeAction(forKey: "timer")
                vehicleNode.runAction(checkpointSound)
                vehicleNode.runAction(relaxSound, forKey: "relax")
                startNode.position.x = -8
                startText.string = "-> Press R <-"
                checkpoint = "startLine"
                if seconds < record {
                    recordText.string = timeText.string
                    record = seconds
                    messageNode.isHidden = false
                    messageNode.runAction(SCNAction.wait(duration: 5)) {
                        self.messageNode.isHidden = true
                    }
                }
            }
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.checkpoint1.rawValue:
            if checkpoint == "startLine" { // checkpoint 1
                vehicleNode.runAction(checkpointSound)
                checkpoint1.isHidden = true
                checkpoint2.isHidden = false
                checkpoint = "checkpoint1"
            }
        case PhysicsMask.vehicle.rawValue | PhysicsMask.checkpoint2.rawValue:
            if checkpoint == "checkpoint1" { // checkpoint 2
                vehicleNode.runAction(checkpointSound)
                checkpoint2.isHidden = true
                checkpoint3.isHidden = false
                checkpoint = "checkpoint2"
            }
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.checkpoint3.rawValue:
            if checkpoint == "checkpoint2" { // checkpoint 3
                vehicleNode.runAction(checkpointSound)
                checkpoint3.isHidden = true
                startText.string = "FINISH"
                startLine.isHidden = false
                checkpoint = "checkpoint3"
            }
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.loop1start.rawValue:
            scnView.pointOfView = loop1camera
            loopСamera = "loop1camera"
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.loop1end.rawValue:
            scnView.pointOfView = getCamera(name: lastPlayerCamera)
            loopСamera = ""
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.loop2start.rawValue:
            scnView.pointOfView = loop2camera
            loopСamera = "loop2camera"
            
        case PhysicsMask.vehicle.rawValue | PhysicsMask.loop2end.rawValue:
            scnView.pointOfView = getCamera(name: lastPlayerCamera)
            loopСamera = ""
            
        default:
            break
        }
    }
}
